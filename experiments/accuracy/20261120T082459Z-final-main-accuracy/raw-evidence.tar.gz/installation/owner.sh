#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
control=$PWD
label=$(basename "$control")
root=/workspace/experiments/minicpm-s2
out="$root/accuracy/$label"
target="$control/installed"
printf '%s\n' "$$" > owner.pid
trap 'printf "%s\n" "$?" > "$control/owner.exit"' EXIT
tar xzf framework.tgz
tar xzf flaggems.tgz
export PIP_DISABLE_PIP_VERSION_CHECK=1
export SETUPTOOLS_SCM_PRETEND_VERSION_FOR_FLAG_GEMS=5.3.5+gbda4a2e047
export SETUPTOOLS_SCM_PRETEND_VERSION_FOR_VLLM_PLUGIN_FL=0.3.0rc0+g6220924c10
python3 -m pip install --no-build-isolation --no-deps --no-index --no-cache-dir --target "$target" ./flaggems ./framework >install.log 2>&1
export PYTHONPATH="$target"
export PYTHONUNBUFFERED=1
python3 - <<'PY'
import hashlib, importlib.metadata as meta, importlib.util, json
from pathlib import Path
control = Path.cwd()
target = control / "installed"
identity = json.loads((control / "source-identity.json").read_text())
for package, info in identity["packages"].items():
    origin = Path(importlib.util.find_spec(package).origin).resolve()
    if origin.parent != target / package:
        raise RuntimeError(f"{package} resolved outside this installation: {origin}")
    info["import_path"] = str(origin)
    info["installed_distribution"] = meta.version(info["distribution"])
    for relative, expected in info["runtime_files"].items():
        got = hashlib.sha256((target / relative).read_bytes()).hexdigest()
        if got != expected:
            raise RuntimeError(f"Installed source differs from Git: {relative}")
(control / "identity.json").write_text(json.dumps(identity, indent=2) + "\n")
(target / "base-revision.txt").write_text(identity["packages"]["vllm_fl"]["commit"] + "\n")
PY
python3 "$root/scripts/run_accuracy_gate.py" "$out" --source-dir "$target"
