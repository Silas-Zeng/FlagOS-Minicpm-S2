#!/usr/bin/env python3
"""Isolated synthetic-ABI Q32 mask candidate worker; owner controls device access."""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, math, os, sys, time, traceback
from pathlib import Path

BASE_SHA = "ac0ee4caaeed8dfd211a57cd4d3d130d8437a2a0129c1c915e1b19ed4fc66b4b"
CAND_SHA = "f4534a6fcc77b68b8d17e5dfb8ddad412a17293c8f6f4e627297141983f6d1a5"
WRITER_SHA = "16afc46585f950f4b9c06c831b0e0dbf5515ee941a476a9ed300c492ebf947f9"
HELPER_SHA = {
 "vllm.v1.attention.ops.triton_attention_helpers":"59d9d34bbda988436593cfdb9cb05015d17db8ee85c50f6697e45f987acbf0b1",
 "vllm.v1.attention.ops.triton_unified_attention":"54c495dcea404582a1526a96ae7e472965cbd03c8fa0931c71ef72223bf04e1f"
}
WARM_HASH = "c0a523d9d0d4d5dde57b241df9d22c9c38fa71e480878d18e690b4eb002e24f7"
WARM = Path("/workspace/experiments/minicpm-s2/profiles/20261029T222344850512Z-mixed-a-16k-profile/triton-cache/YCSSHWOQ2TK53ZL3EQO7TURMTQ4PU4PEQCDY2GHGSC2OWABOET3Q")
SHAPES = ((1048, 2018, 12108, 14126), (1042, 2018, 0, 2018), (1049, 2019, 14126, 16145))

def sha_bytes(b: bytes) -> str: return hashlib.sha256(b).hexdigest()
def sha_file(p: Path) -> str: return sha_bytes(p.read_bytes())
def need(ok, msg):
    if not ok: raise RuntimeError(msg)
def load_module(path: Path, name: str):
    spec=importlib.util.spec_from_file_location(name,path)
    if spec is None or spec.loader is None: raise RuntimeError(f"cannot import {path}")
    mod=importlib.util.module_from_spec(spec); sys.modules[name]=mod; spec.loader.exec_module(mod); return mod
def dump_compiled(compiled, out: Path):
    init=getattr(compiled,"_init_handles",None)
    if callable(init): init()
    out.mkdir(parents=True,exist_ok=True)
    asm=getattr(compiled,"asm",{}) or {}
    for ext,val in asm.items():
        if isinstance(val,str): (out/f"kernel.{ext}").write_text(val,encoding="utf-8",newline="\n")
        elif isinstance(val,(bytes,bytearray)): (out/f"kernel.{ext}.bin").write_bytes(bytes(val))
    md=getattr(compiled,"metadata",None)
    meta={"hash":getattr(compiled,"hash",None),"n_regs":getattr(compiled,"n_regs",None),
          "n_spills":getattr(compiled,"n_spills",None),"metadata":str(md),
          "metadata_shared":getattr(md,"shared",None),"metadata_num_warps":getattr(md,"num_warps",None)}
    (out/"resources.json").write_text(json.dumps(meta,indent=2)+"\n",encoding="utf-8")
    return meta
def bits_equal(torch,a,b):
    return torch.equal(a.contiguous().view(torch.uint8),b.contiguous().view(torch.uint8))
def tensor_hash(t,torch): return sha_bytes(t.detach().contiguous().view(torch.uint8).view(-1).cpu().numpy().tobytes())

def make_kwargs(torch, key_source, value_source, q, layer, seq, table, out, context, total):
    pages=layer.numel()//4096
    # Reinterpret a single 16KiB/page backing according to the production view recipe.
    base_bytes=layer.view(torch.uint8)
    code=base_bytes.view(torch.int8)
    scale_full=base_bytes.view(torch.float32)
    value_full=base_bytes.view(torch.bfloat16)
    key=code.as_strided((pages,16,2,128),(16384,256,128,1))
    value=value_full.as_strided((pages,16,2,128),(8192,256,128,1),storage_offset=4096)
    qrows=q.shape[0]
    cu=torch.tensor([0,qrows],dtype=torch.int32,device="cuda")
    return dict(output_ptr=out,query_ptr=q,key_cache_ptr=key,key_code_scale_ptr=scale_full,
      value_cache_ptr=value,sink_ptr=None,block_tables_ptr=table,seq_lens_ptr=seq,
      alibi_slopes_ptr=None,qq_bias_ptr=None,scale=128**-0.5,q_scale=1.0,k_scale=1.0,
      v_scale=1.0,out_scale=1.0,softcap=0,num_query_heads=16,num_queries_per_kv=8,
      block_table_stride=table.stride(0),query_stride_0=2048,query_stride_1=128,
      output_stride_0=2048,output_stride_1=128,qq_bias_stride_0=0,BLOCK_SIZE=16,
      TILE_SIZE=64,HEAD_SIZE=128,HEAD_SIZE_PADDED=128,USE_ALIBI_SLOPES=False,
      USE_ALIBI_SQRT=False,USE_QQ_BIAS=False,USE_SOFTCAP=False,USE_SINKS=False,
      SLIDING_WINDOW=0,USE_CAUSAL=True,USE_PER_SEQ_CAUSAL=False,per_seq_causal_ptr=None,
      USE_MM_PREFIX=False,MAX_MM_RANGES=0,mm_prefix_range_ptr=None,
      stride_k_cache_0=16384,stride_k_cache_1=256,stride_k_cache_2=128,stride_k_cache_3=1,
      stride_v_cache_0=8192,stride_v_cache_1=256,stride_v_cache_2=128,stride_v_cache_3=1,
      query_start_len_ptr=cu,BLOCK_Q=32,num_seqs=1,BLOCK_M=256,NUM_SEGMENTS_PER_SEQ=1,
      USE_FP8=False,IS_3D=False,segm_output_ptr=None,segm_max_ptr=None,segm_expsum_ptr=None,
      k_scale_cache_ptr=key,v_scale_cache_ptr=value,stride_ks_blk=0,stride_ks_slot=0,
      stride_ks_head=0,stride_vs_blk=0,stride_vs_slot=0,stride_vs_head=0,
      KV_QUANT_MODE=0,CHUNK_LOOKBACK=-1,CHUNK_SIZE=-1,USE_TD=False,USE_TD_QO=False,Q_IS_FP8=False)

def make_case(torch, writer, qrows, context, total, seed, device):
    pages=(total+15)//16
    gen=torch.Generator(device=device).manual_seed(seed)
    q=torch.randn((qrows,16,128),generator=gen,device=device,dtype=torch.float32).to(torch.bfloat16)
    ksrc=torch.randn((total,2,128),generator=gen,device=device,dtype=torch.float32).to(torch.bfloat16)
    vsrc=torch.randn((total,2,128),generator=gen,device=device,dtype=torch.float32).to(torch.bfloat16)
    page_ids=torch.arange(pages-1,-1,-1,dtype=torch.int32,device=device)
    table=torch.full((1,1024),-1,dtype=torch.int32,device=device); table[0,:pages]=page_ids
    slots=page_ids[torch.arange(total,device=device)//16].to(torch.int64)*16+torch.arange(total,device=device,dtype=torch.int64)%16
    backing=torch.empty((pages*16384,),dtype=torch.uint8,device=device); backing.fill_(0x5a)
    code=backing.view(torch.int8); scales=backing.view(torch.float32); values=backing.view(torch.bfloat16)
    writer.encode_append[(total,2)](ksrc,vsrc,slots,code,scales,values,
       key_row_stride=256,value_row_stride=256,key_rows=total,value_rows=total,
       slot_count=total,cache_pages=pages)
    torch.cuda.synchronize()
    seq=torch.tensor([total],dtype=torch.int32,device=device)
    output_storage=torch.full(((qrows+2)*2048,),float("nan"),dtype=torch.bfloat16,device=device)
    out=output_storage.as_strided((qrows,16,128),(2048,128,1),storage_offset=2048)
    kw=make_kwargs(torch,ksrc,vsrc,q,backing.view(torch.float32),seq,table,out,context,total)
    return dict(q=q,ksrc=ksrc,vsrc=vsrc,slots=slots,backing=backing,seq=seq,table=table,
                cu=kw['query_start_len_ptr'],output=out,output_storage=output_storage,
                kwargs=kw,context=context,total=total,pages=pages)

def fresh_output(torch, qrows):
    storage=torch.full(((qrows+2)*2048,),13.0,dtype=torch.bfloat16,device="cuda")
    out=storage.as_strided((qrows,16,128),(2048,128,1),storage_offset=2048)
    out.fill_(float("nan"))
    return storage,out

def output_guard_ok(torch, storage, qrows):
    return bool((storage[:2048] == 13.0).all().item()
                and (storage[(qrows+1)*2048:] == 13.0).all().item())

def tensor_desc(t):
    return {"dtype":str(t.dtype),"shape":list(t.shape),"stride":list(t.stride()),
            "storage_offset_elements":int(t.storage_offset()),"data_ptr":int(t.data_ptr())}

def serialize_args(kwargs):
    return {k:(tensor_desc(v) if hasattr(v,"dtype") and hasattr(v,"shape") and hasattr(v,"stride")
               else v if v is None or type(v) in (bool,int,float,str) else repr(v))
            for k,v in kwargs.items()}

def run_arm(torch, kernel, case, grid):
    storage,out=fresh_output(torch,case['q'].shape[0])
    kw=dict(case['kwargs']); kw['output_ptr']=out
    kernel[grid](**kw,num_warps=16,num_stages=1)
    torch.cuda.synchronize()
    return out,output_guard_ok(torch,storage,case['q'].shape[0])

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--baseline',type=Path,default=Path(__file__).resolve().parents[1]/'baseline.py')
    ap.add_argument('--candidate',type=Path,default=Path(__file__).resolve().parents[1]/'candidate.py')
    ap.add_argument('--writer-source',type=Path,default=Path(__file__).resolve().parents[1]/'writer.py')
    ap.add_argument('--gpu',action='store_true',help='required explicit device phase')
    args=ap.parse_args(); args.out.parent.mkdir(parents=True,exist_ok=True)
    result={"status":"running","component_only":True,"synthetic_abi":True,
      "service_capture_claim":False,"source_hashes":{},"compile":{},"cases":[],"errors":[]}
    def save(): args.out.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    try:
      need(args.gpu,"--gpu required; owner controls lock/preflight")
      need(sha_file(args.baseline)==BASE_SHA,"baseline source SHA mismatch")
      need(sha_file(args.candidate)==CAND_SHA,"candidate SHA mismatch")
      need(sha_file(args.writer_source)==WRITER_SHA,"actual encoded writer SHA mismatch")
      import torch
      need(torch.cuda.is_available(),"target CUDA/CoreX device unavailable")
      helper_identity={}
      for name,expected in HELPER_SHA.items():
        helper=__import__(name,fromlist=['*']); path=Path(helper.__file__).resolve()
        actual=sha_file(path); helper_identity[name]={"path":str(path),"sha256":actual}
        need(actual==expected,f"runtime helper SHA mismatch for {name}")
      a=load_module(args.baseline,"q32_mask_baseline")
      b=load_module(args.candidate,"q32_mask_candidate")
      w=load_module(args.writer_source,"q32_konly_writer")
      need(hasattr(a,"kernel_cjj_konly_q32") and hasattr(b,"kernel_cjj_konly_q32"),"JIT kernel missing")
      result['source_hashes']={"baseline":sha_file(args.baseline),"candidate":sha_file(args.candidate),"writer":sha_file(args.writer_source)}
      result['runtime_helpers']=helper_identity
      # Compile first, before any tested attention launch. All cases share strides/constexprs.
      primary=make_case(torch,w,2018,12108,14126,73019,'cuda')
      grid=(2018//32+1,2)
      result['synthetic_abi']={"claim":"explicitly constructed from frozen q32 JIT signature + encoded views; not a service capture",
        "query":tensor_desc(primary['kwargs']['query_ptr']),"output":tensor_desc(primary['kwargs']['output_ptr']),
        "key_codes":tensor_desc(primary['kwargs']['key_cache_ptr']),"key_scales":tensor_desc(primary['kwargs']['key_code_scale_ptr']),
        "value":tensor_desc(primary['kwargs']['value_cache_ptr']),"block_table":tensor_desc(primary['table']),
        "seq_lens":tensor_desc(primary['seq']),"query_start_len":tensor_desc(primary['kwargs']['query_start_len_ptr']),
        "config":{k:primary['kwargs'][k] for k in ('IS_3D','BLOCK_M','BLOCK_Q','TILE_SIZE','HEAD_SIZE','BLOCK_SIZE',
          'num_query_heads','num_queries_per_kv','KV_QUANT_MODE','num_seqs','num_warps') if k in primary['kwargs']},
        "grid":list(grid),"page_bytes":16384,"page_tokens":16,"table_stride":1024,
        "codec":"frozen encode_append RN32/RNE int8 K + per-token-head f32 scales; BF16 V",
        "all_kernel_arguments":serialize_args(primary['kwargs']),"compile_options":{"num_warps":16,"num_stages":1}}
      comp=[]
      for label,kernel in (("A",a.kernel_cjj_konly_q32),("B",b.kernel_cjj_konly_q32)):
        built=kernel.warmup(**primary['kwargs'],grid=grid,num_warps=16,num_stages=1)
        meta=dump_compiled(built,args.out.parent/'compile'/label)
        comp.append(meta)
      result['compile']={"A":comp[0],"B":comp[1],"grid":grid,"warm_hash":WARM_HASH,
                         "A_hash_matches_warm":comp[0]['hash']==WARM_HASH,
                         "A_shared_matches_warm":comp[0]['metadata_shared']==57344,
                         "warm_match_is_diagnostic_not_synthetic_abi_qualification":True,
                         "compile_only_before_numeric":True}
      save()
      # The saved reference compiler artifacts must exist before the first reader launch.
      for case_id,qrows,context,total in SHAPES:
        case=make_case(torch,w,qrows,context,total,73019+case_id,'cuda')
        grid=(qrows//32+1,2)
        inp={name:t.clone() for name,t in (("q",case['q']),("ksrc",case['ksrc']),("vsrc",case['vsrc']),
             ("slots",case['slots']),("backing",case['backing']),("seq",case['seq']),("table",case['table']),("cu",case['cu']))}
        oa,ga=run_arm(torch,a.kernel_cjj_konly_q32,case,grid)
        ob,gb=run_arm(torch,b.kernel_cjj_konly_q32,case,grid)
        finite=bool(torch.isfinite(oa.float()).all().item() and torch.isfinite(ob.float()).all().item())
        same=bits_equal(torch,oa,ob)
        unchanged=all(torch.equal(inp[n],case[n]) for n in inp)
        record={"step":case_id,"q":qrows,"context":context,"total_kv":total,"grid":list(grid),
                "finite":finite,"A_B_bitwise":same,"output_guards_unchanged":bool(ga and gb),"inputs_and_cache_unchanged":unchanged,
                "A_sha256":tensor_hash(oa,torch),"B_sha256":tensor_hash(ob,torch),"timing_ms":None}
        result['cases'].append(record); save()
        if not (finite and same and ga and gb and unchanged):
          torch.save({"step":case_id,"q":case['q'].cpu(),"key_source":case['ksrc'].cpu(),
             "value_source":case['vsrc'].cpu(),"encoded_backing":case['backing'].cpu(),
             "slots":case['slots'].cpu(),"seq_lens":case['seq'].cpu(),"block_table":case['table'].cpu(),
             "A_output":oa.cpu(),"B_output":ob.cpu(),"A_guard_ok":ga,"B_guard_ok":gb},
             args.out.parent/f"failure-step{case_id}.pt")
        need(finite and same and ga and gb and unchanged,f"numeric/guard gate failed at step {case_id}")
        if case_id==1048:
          # Same cache/table, changed Q proves runtime Q is consumed. No graph capture: production Q32 is eager-only.
          q2=case['q'].flip(0).contiguous(); q2_saved=q2.clone(); kw2=dict(case['kwargs']); kw2['query_ptr']=q2
          changed=dict(case); changed['kwargs']=kw2
          ca,ga2=run_arm(torch,a.kernel_cjj_konly_q32,changed,grid); cb,gb2=run_arm(torch,b.kernel_cjj_konly_q32,changed,grid)
          change_ok=bits_equal(torch,ca,cb) and bool(torch.isfinite(cb.float()).all().item())
          changes_output=not bits_equal(torch,ca,oa)
          changed_inputs_ok=torch.equal(q2,q2_saved) and all(torch.equal(inp[k],case[k]) for k in ('q','backing','table','seq','slots','ksrc','vsrc','cu'))
          record['changed_q_eager_bitwise']=bool(change_ok); record['changed_q_changes_output']=bool(changes_output)
          record['changed_q_cache_inputs_unchanged']=bool(changed_inputs_ok)
          record['changed_q_A_sha256']=tensor_hash(ca,torch); record['changed_q_B_sha256']=tensor_hash(cb,torch); save()
          need(change_ok and changes_output and changed_inputs_ok and ga2 and gb2,"changed-Q eager bitwise/change/guard gate failed")
      # Only primary measured, once in ABBA order after all numeric gates.
      p=make_case(torch,w,2018,12108,14126,73019,'cuda'); grid=(2018//32+1,2)
      timing_inputs={k:t.clone() for k,t in (("q",p['q']),("ksrc",p['ksrc']),("vsrc",p['vsrc']),
                       ("slots",p['slots']),("backing",p['backing']),("seq",p['seq']),("table",p['table']),("cu",p['cu']))}
      warm=[]
      for kernel in (a.kernel_cjj_konly_q32,b.kernel_cjj_konly_q32):
        warm.append(run_arm(torch,kernel,p,grid))
      torch.cuda.synchronize()
      times=[]
      for group in range(4):
        group_outputs={"A":[],"B":[]}
        for arm,kernel in (("A",a.kernel_cjj_konly_q32),("B",b.kernel_cjj_konly_q32),
                           ("B",b.kernel_cjj_konly_q32),("A",a.kernel_cjj_konly_q32)):
          storage,out=fresh_output(torch,2018); kw=dict(p['kwargs']); kw['output_ptr']=out
          start=torch.cuda.Event(enable_timing=True); end=torch.cuda.Event(enable_timing=True)
          host_start=time.perf_counter(); start.record()
          for _ in range(50): kernel[grid](**kw,num_warps=16,num_stages=1)
          end.record(); end.synchronize(); host_ms=(time.perf_counter()-host_start)*1000
          finite=bool(torch.isfinite(out.float()).all().item()); guard=output_guard_ok(torch,storage,2018)
          digest=tensor_hash(out,torch); group_outputs[arm].append(out.detach().clone())
          times.append({"group":group,"arm":arm,"repetitions":50,"event_mean_ms":float(start.elapsed_time(end))/50,
                        "host_block_ms":host_ms,"output_sha256":digest,"finite":finite,"output_guard_unchanged":guard})
          need(finite and guard,"ABBA post-timing output/guard failure")
        if not (bits_equal(torch,group_outputs['A'][0],group_outputs['A'][1])
             and bits_equal(torch,group_outputs['B'][0],group_outputs['B'][1])
             and bits_equal(torch,group_outputs['A'][0],group_outputs['B'][0])):
          torch.save({"group":group,"outputs":{k:[x.cpu() for x in v] for k,v in group_outputs.items()}},
                     args.out.parent/f"failure-abba-group{group}.pt")
        need(bits_equal(torch,group_outputs['A'][0],group_outputs['A'][1])
             and bits_equal(torch,group_outputs['B'][0],group_outputs['B'][1])
             and bits_equal(torch,group_outputs['A'][0],group_outputs['B'][0]),f"ABBA group {group} bitwise failure")
        result['primary_abba']=times; save()
      need(all(torch.equal(timing_inputs[k],p[k]) for k in timing_inputs),"ABBA modified input or encoded cache")
      result['primary_abba']=times; result['status']='complete'; save()
    except Exception as exc:
      result['status']='failed'; result['errors'].append({"type":type(exc).__name__,"message":str(exc),"traceback":traceback.format_exc()}); save(); raise
    return 0
if __name__=='__main__': raise SystemExit(main())
