"""Root 单独启动的 Q32 组件 owner；复用唯一设备锁，终态打包原件。"""
from pathlib import Path
import argparse, datetime, hashlib, io, json, os, signal, socket, subprocess, sys, tarfile, traceback

ROOT=Path('/workspace/experiments/minicpm-s2')
HERE=Path(__file__).resolve().parent
PACKAGE=HERE.parent

def sha(p):
    with Path(p).open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def preflight(out,label):
    for family,addr in ((socket.AF_INET,'127.0.0.1'),(socket.AF_INET6,'::1')):
        try:
            with socket.socket(family) as s:
                s.settimeout(1)
                if s.connect_ex((addr,9031))==0: raise RuntimeError('port 9031 is occupied')
        except OSError:
            if family==socket.AF_INET: raise
    p=subprocess.run(['/usr/local/corex-4.5.0/bin/ixsmi'],capture_output=True,text=True,timeout=20)
    (out/(label+'-ixsmi.txt')).write_text(p.stdout+p.stderr,encoding='utf-8')
    if p.returncode or 'No running processes found' not in p.stdout:
        raise RuntimeError('GPU has another process or state is unknown')
    return {'utc':now(),'port_9031':'free','gpu_processes':'none'}
def stop(child):
    if child is None or child.poll() is not None:return
    try: os.killpg(child.pid,signal.SIGTERM)
    except ProcessLookupError:return
    try: child.wait(timeout=20)
    except subprocess.TimeoutExpired:
        os.killpg(child.pid,signal.SIGKILL);child.wait()
def interrupted(signum,frame): raise KeyboardInterrupt('signal '+str(signum))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--gpu',action='store_true',required=True)
    ap.add_argument('--root-owned-exclusive',action='store_true',required=True)
    ap.add_argument('--out',type=Path,required=True)
    a=ap.parse_args();out=a.out.resolve()
    recovery_target=ROOT/(out.name+'-recovery.tar.gz')
    if ROOT not in out.parents or out.exists():ap.error('fresh output under experiment root required')
    if recovery_target.exists():ap.error('recovery bundle path already exists; refusing overwrite')
    out.mkdir(parents=True)
    import fcntl
    state={'started_utc':now(),'owner_pid':os.getpid(),'run':str(out),'status':'starting',
           'official_performance':False,'accuracy_qualification':False,'source_baseline_sha256':sha(PACKAGE/'baseline.py'),
           'candidate_sha256':sha(PACKAGE/'candidate.py')}
    save(out/'state.json',state);child=None;lock=None;ran=False
    signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
    try:
        lock=(ROOT/'framework-device.lock').open('a')
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        state['preflight']=preflight(out,'preflight')
        env=dict(os.environ)
        options={'TRITON_CACHE_DIR':str(out/'triton-cache'),'VLLM_CACHE_ROOT':str(out/'vllm-cache'),
                 'VLLM_PLUGINS':'','PYTHONHASHSEED':'0'}
        env.update(options)
        save(out/'environment.json',{'overrides':options,'python':sys.executable,'platform':sys.platform})
        command=[sys.executable,'-u',str(HERE/'worker.py'),'--gpu','--out',str(out/'summary.json')]
        state.update(command=command,status='running');save(out/'state.json',state)
        with (out/'worker.log').open('xb') as log:
            child=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,
                                   cwd=PACKAGE,env=env,start_new_session=True)
            ran=True;state['child_pid']=child.pid;save(out/'state.json',state)
            try: rc=child.wait(timeout=900)
            except subprocess.TimeoutExpired:
                stop(child);raise RuntimeError('owned component exceeded 900 seconds')
        state['worker_returncode']=rc
        if rc:raise RuntimeError('component worker returned '+str(rc))
        state['summary_sha256']=sha(out/'summary.json');state['status']='completed'
    except BaseException:
        state.update(status='failed',error=traceback.format_exc())
    finally:
        stop(child)
        if lock is not None:
            if ran:
                try:state['postflight']=preflight(out,'postflight')
                except Exception:state.update(status='failed',cleanup_error=traceback.format_exc())
            lock.close()
        state['finished_utc']=now();save(out/'state.json',state)
    rows=[]
    for directory in (PACKAGE,out):
        for p in sorted(directory.rglob('*')):
            if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts:
                rows.append({'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)})
    bundle=ROOT/(out.name+'-recovery.tar.gz')
    with tarfile.open(bundle,'w:gz') as tf:
        for row in rows:tf.add(ROOT/row['path'],arcname=row['path'],recursive=False)
        raw=json.dumps({'run':out.name,'files':rows},ensure_ascii=False,indent=2).encode()
        info=tarfile.TarInfo('manifest.json');info.size=len(raw);tf.addfile(info,io.BytesIO(raw))
    terminal={'state':state,'bundle':str(bundle),'sha256':sha(bundle),'bytes':bundle.stat().st_size,'files':len(rows)}
    print(json.dumps(terminal,ensure_ascii=False),flush=True)
    return 0 if state['status']=='completed' else 1

if __name__=='__main__':raise SystemExit(main())

