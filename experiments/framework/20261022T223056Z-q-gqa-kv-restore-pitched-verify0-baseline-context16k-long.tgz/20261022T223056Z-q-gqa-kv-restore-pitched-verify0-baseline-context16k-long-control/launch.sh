#!/usr/bin/env bash
# root实际验收222222 VERIFY1后手动单侧启动；复用原owner，无自动pair。
set -euo pipefail
test "$#" -ge 2
variant=$1
verify1_review=$2
[[ "$variant" == baseline || "$variant" == candidate ]]
if [[ "$variant" == baseline ]]; then
  test "$#" -eq 2
  baseline_control=''
else
  test "$#" -eq 3
  baseline_control=$3
fi
root=/workspace/experiments/minicpm-s2
assets=$(cd -- "$(dirname -- "$0")" && pwd)
case "$variant" in
  baseline)
    source_dir="$root/code/q-gqa-kv-swap-20261022T213134Z"
    reference="$root/framework/20261022T213134Z-q-gqa-kv-swap-verify1-context16k-long-control"
    marker=BIV150_KV_PROTOCOL_INSTALLED ;;
  candidate)
    source_dir="$root/code/q-gqa-kv-restore-pitched-20261022T222222Z"
    reference="$root/framework/20261022T222222Z-q-gqa-kv-restore-pitched-verify1-context16k-long-control"
    marker=BIV150_KV_PROTOCOL_INSTALLED ;;
esac
stamp=$(date -u +%Y%m%dT%H%M%SZ)
run="$root/framework/$stamp-q-gqa-kv-restore-pitched-verify0-$variant-context16k-long"
control="$run-control"
python3 - "$root" "$assets" "$verify1_review" <<'PY'
from pathlib import Path
import hashlib, json, socket, subprocess, sys
root, assets, review = map(Path, sys.argv[1:])
for path,pin in {
    assets/'base-source-sha256.json':'82514a24cebdb3ae8ce8eb1562049168fa158894364d1dd87ae4b4a724f66136',
    assets/'restore-source-sha256.json':'fb8b867222b7b1c867e457c4c3f7f72cb6e4dce42ad528f28aa211c8cf7734ed',
    root/'scripts/run_framework_screen.py':'bc51ac2d9daf90205bde362f8384b1ac34238e7be932e9a6df7fc618d7350be9',
    root/'scripts/snapshot_tuning_db.py':'0f2a57bf3bdb858756a1dedab5bd386a3a8bff384d925cf76461afb8c097e7a2',
}.items():
    if hashlib.sha256(path.read_bytes()).hexdigest()!=pin:
        raise RuntimeError('冻结输入/driver/DB工具变化: '+str(path))
first = root/'framework/20261022T222222Z-q-gqa-kv-restore-pitched-verify1-context16k-long'
if (first/'exit-code').read_text().strip()!='0':
    raise RuntimeError('222222 VERIFY1尚未完成')
post = json.loads((first/'postflight-full.json').read_text())
if (post['source_count']!=425 or post['source_failures'] or post['query'].strip()!='68, 0'
        or not all(post['ports_closed'].values())):
    raise RuntimeError('222222后态尚未收口')
passed = json.loads(review.read_text(encoding='utf-8'))
if (passed.get('status') != 'passed_qgqa_pitched_full_restore_verify1_compatibility'
        or passed.get('evidence',{}).get('run_id') != first.name
        or passed['evidence'].get('source_count_verified') != 425
        or passed.get('source_manifest_sha256') != 'fb8b867222b7b1c867e457c4c3f7f72cb6e4dce42ad528f28aa211c8cf7734ed'
        or passed.get('passed_H2D_gate',{}).get('bridge_sha256') != 'f9bf8757133b084cd198ea8a8b0b217af887ac03b2f2bfb9599fd806a9801d2c'):
    raise RuntimeError('必须显式提供本425实际VERIFY1通过报告；exit0/安装不足')
query = subprocess.check_output(['ixsmi', '--query-gpu=memory.used,utilization.gpu', '--format=csv,noheader,nounits'], text=True)
table = subprocess.check_output(['ixsmi'], text=True)
if (query.strip()!='68, 0' or 'No running processes found' not in table
        or 'BI-V150' not in table or '32768MiB' not in table):
    raise RuntimeError('不是空闲单BI-V150/32GiB: '+query)
for family, host in ((socket.AF_INET, '127.0.0.1'), (socket.AF_INET6, '::1')):
    with socket.socket(family, socket.SOCK_STREAM) as sock:
        sock.settimeout(2)
        if sock.connect_ex((host, 9031))==0:
            raise RuntimeError('9031正在使用: '+host)
PY
mkdir "$control"
cp "$0" "$control/launch.sh"
cp "$assets/base-source-sha256.json" "$assets/restore-source-sha256.json" "$control/"
cp "$verify1_review" "$control/passed-verify1-review.json"
python3 - "$control" "$source_dir" "$reference" "$variant" <<'PY'
from pathlib import Path
import hashlib, json, shutil, sys
control, source, reference = map(Path, sys.argv[1:4]); variant = sys.argv[4]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def mapping(folder):
    result = {}
    for path in sorted(folder.rglob('*')):
        rel = path.relative_to(folder)
        if any(x in ('.git','__pycache__') for x in rel.parts) or path.suffix in ('.pyc','.pyo'):
            continue
        if path.is_symlink():
            target = path.resolve(strict=True)
            if not target.is_file() or not target.is_relative_to(folder):
                raise RuntimeError('源含外部/目录链接')
        if path.is_file(): result[rel.as_posix()] = sha(path)
    return result
expected = json.loads((control/('base-source-sha256.json' if variant=='baseline' else 'restore-source-sha256.json')).read_text())
original = json.loads((reference/'source-sha256.json').read_text())
if len(expected)!=(422 if variant=='baseline' else 425) or original!=expected or mapping(source)!=expected:
    raise RuntimeError('完整现有冻结源/原source证据不符')
shutil.copytree(source, control/'plugin-source')
if mapping(control/'plugin-source')!=expected or mapping(source)!=expected:
    raise RuntimeError('源码归档不符或源在归档期间变化')
evidence = control/'original-source-evidence'; evidence.mkdir()
for name in ('source-sha256.json','purpose.json','preparation.json','command.txt'):
    shutil.copyfile(reference/name, evidence/name)
purpose = {'kind':'QGQA原swap422 vs仅FULL H2D pitched425 VERIFY0单侧；root验收VERIFY1后手动',
    'variant':variant,'source':str(source),'source_count':len(expected),'reference_control':str(reference),
    'reference_file_sha256':{p.name:sha(p) for p in evidence.iterdir()},'verify_restore':'0',
    'limits':['非profiler/不新增字节回读；不自动pair','需真实协议/消费者/QGQA与DB四端/实际KV可比；425不继承422 accuracy']}
(control/'source-sha256.json').write_text(json.dumps(expected,indent=2)+'\n')
(control/'purpose.json').write_text(json.dumps(purpose,ensure_ascii=False,indent=2)+'\n')
PY
cp "$root/scripts/snapshot_tuning_db.py" "$control/"
python3 "$control/snapshot_tuning_db.py" --database /root/.flaggems/config_cache/TunedConfig_iluvatar_triton_3_6.db --output "$control/db-before" > "$control/db-before.log"
# candidate只接受本launcher已完成baseline的共同三SHA DB；不恢复/改写数据库。
python3 - "$root" "$control" "$variant" "$baseline_control" <<'PY'
from pathlib import Path
import json, re, sys
root, control = map(Path, sys.argv[1:3]); variant, reference = sys.argv[3:]
if variant == 'candidate':
    previous = Path(reference)
    if (not previous.is_absolute() or previous.resolve() != previous or previous.parent != root/'framework'
            or not re.fullmatch(r'\d{8}T\d{6}Z-q-gqa-kv-restore-pitched-verify0-baseline-context16k-long-control', previous.name)):
        raise RuntimeError('candidate必须指定本轮已完成baseline control')
    old_run = previous.with_name(previous.name[:-8])
    purpose = json.loads((previous/'purpose.json').read_text())
    post = json.loads((old_run/'postflight-full.json').read_text())
    expected = json.loads((control/'base-source-sha256.json').read_text())
    if ((old_run/'exit-code').read_text().strip()!='0' or purpose['variant']!='baseline'
            or purpose['source']!=str(root/'code/q-gqa-kv-swap-20261022T213134Z')
            or json.loads((previous/'source-sha256.json').read_text())!=expected
            or post['source_count']!=422 or post['source_failures']
            or post['query'].strip()!='68, 0' or not all(post['ports_closed'].values())):
        raise RuntimeError('baseline未完整完成封存')
    paths = [previous/'db-before/manifest.json', previous/'db-after/manifest.json', control/'db-before/manifest.json']
    snapshots = [json.loads(p.read_text()) for p in paths]
    fields = ('snapshot_sha256','schema_sha256','logical_content_sha256')
    values = [{k:s[k] for k in fields} for s in snapshots]
    if any(s.get('status')!='complete' for s in snapshots) or not values[0]==values[1]==values[2]:
        raise RuntimeError('baseline前后与candidate before DB三SHA不一致，不启动/不凑库')
    (control/'common-db-check.json').write_text(json.dumps({'baseline_control':str(previous),
        'matched_three_sha256':values[0], 'candidate_after_still_required':True},indent=2)+'\n')
PY
mkdir "$control/q-hoist-artifacts"
command=(env -u BIV150_FINITE_GROWTH_ADMISSION
  "BIV150_KV_VERIFY_RESTORE=0"
  "BIV150_Q_FRAGMENT_SERVICE_ARTIFACT_DIR=$control/q-hoist-artifacts"
  python3 "$root/scripts/run_framework_screen.py" "$run" --source-dir "$source_dir"
  --context-long-screen --seed 721201 --require-log-marker "$marker")
printf '%q ' "${command[@]}" > "$control/command.txt"
printf '\n' >> "$control/command.txt"
nohup "${command[@]}" > "$control/runner.log" 2>&1 < /dev/null &
runner_pid=$!
printf '%s\n' "$runner_pid" > "$control/runner.pid"
printf 'RUN=%s\nCONTROL=%s\nSOURCE=%s\nVARIANT=%s\nRUNNER_PID=%s\nVERIFY=0\n' "$run" "$control" "$source_dir" "$variant" "$runner_pid"
