"""固定N64/S2/KV4096：当前PR105 macro1对冻结7db363d48KiB T32原位复用完整Graph ABBA。"""
from pathlib import Path
from types import SimpleNamespace as NS
import hashlib,importlib,json,os,statistics,subprocess,traceback
from legacy_gate import timed_batch
from fp_reference import sampled_reference
from validate_hidden_row_gather import digest,write
from validate_mixed_decode import make_data
HERE=Path(__file__).resolve().parent
GQA_SHA='c8a725daa29f7fb077d15f04dd9a3be8a419e12e857cc46b4b62870d4f97421b'
def require(x,message):
 if not x:raise RuntimeError(message)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
class Capture:
 def __init__(self,original):self.original,self.records=original,[]
 def __getitem__(self,grid):
  def launch(*args,**kw):
   require(not args,'Expected actual keyword ABI')
   compiled=self.original[grid](**kw);self.records.append((grid,dict(kw),compiled));return compiled
  return launch

def worker(run,model,case='hotspot'):
 run=Path(run);model=Path(model)
 result=dict(status='started',checks=[],timings=[],kind='strict native macro1/t32_reuse complete producer+same reducer Graph ABBA',
  shape=dict(N=64,S=2,KV=4096,cache_capacity=16384,Q_stride=[2048,128,1]),
  limits=['One shape and a strict same-run native comparison; no model/official throughput qualification.',
   'New two-page numerical order: original FP64/nonfinite/Graph/input/RNG gates; cross-arm output/partial bits are diagnostic.',
   'A is current PR105 macro1; T32 reuse8KiB keeps parent math and changes shared lifetime; all nine GPU gates rerun, no new performance qualification.'])
 runtime=gqa=None;original_try=None;original_reducer=None;restore_needed=False;had_try_attr=False
 try:
  require(case=='hotspot','Only N64/S2/KV4096, no queue')
  import torch
  import vllm_fl
  from torch.utils.cpp_extension import load as build
  from vllm.config import CompilationConfig,CUDAGraphMode,set_current_vllm_config
  from vllm.engine.arg_utils import EngineArgs
  from vllm.v1.kv_cache_interface import FullAttentionSpec
  library=Path(os.environ['BIV150_NATIVE_GQA_LIBRARY']);require(sha(library)==GQA_SHA,'A is not current c8a725')
  receipt=json.loads((HERE/'macro1-build-receipt.json').read_text());require(receipt['library_sha256']==GQA_SHA and receipt['overlap_v'] is True,'A macro1 receipt mismatch')
  result['macro1']=dict(library=str(library),sha256=GQA_SHA,overlap_v=True,namespace='corex_native_gqa_s2_probe',
   build_commands_sha256=receipt['build_commands_sha256'],source_sha256=receipt['source_sha256'])
  config=EngineArgs(model=str(model),served_model_name=['minicpm'],gpu_memory_utilization=.85,max_model_len=131072,
   compilation_config=CompilationConfig(cudagraph_mode=CUDAGraphMode.FULL_DECODE_ONLY)).create_engine_config()
  t=config.model_config.hf_text_config
  require((t.hidden_size,t.intermediate_size,t.num_hidden_layers,t.num_attention_heads,t.num_key_value_heads)==(2048,6144,42,16,2),'Wrong model')
  require(config.model_config.dtype==torch.bfloat16 and model.name=='MiniCPM5-2B','Wrong model dtype')
  with set_current_vllm_config(config):
   import distributed_bootstrap
   distributed_bootstrap.initialize(config,run)
   from vllm_fl.ops.custom_ops import register_oot_ops
   from dispatch_bootstrap import enable_dispatch
   register_oot_ops();result['dispatch']=enable_dispatch(torch,run)
   importlib.import_module('vllm_fl.worker.model_runner')
   result['native_gate_install']=importlib.import_module('vllm_fl.patches.biv150_native_w8a8').install()
  require(result['native_gate_install'].get('installed'),'Original native14f chain absent')
  gqa=importlib.import_module('vllm_fl.patches.biv150_gqa_decode')
  native=importlib.import_module('vllm_fl.patches.biv150_native_gqa')
  backend=importlib.import_module('vllm.v1.attention.backends.triton_attn')
  runtime=gqa._native_s2
  require(type(runtime) is native._Runtime and runtime.library_sha256==GQA_SHA,'Actual runtime is not native c8a725')
  require(torch.cuda.device_count()==1,'Not one GPU');torch.cuda.set_device(0)
  props=torch.cuda.get_device_properties(0)
  require('BI-V150' in props.name and props.multi_processor_count==16,'Not BI-V15016SM')
  result['device']=str(props)
  os.environ['MAX_JOBS']='1';os.environ['TORCH_CUDA_ARCH_LIST']='7.1'
  builddir=run/'t32_reuse-build';builddir.mkdir()
  flags=['-O3','-std=c++17','-D__ILUVATAR__','-D__MR__','-x','ivcore','--cuda-gpu-arch=ivcore11','--cuda-path=/usr/local/corex']
  private_lib=build(name='corex_native_gqa_t32_reuse_component',sources=[str(HERE/'bridge.cpp'),str(HERE/'native_gqa_t32_reuse.cu')],
   build_directory=str(builddir),extra_cflags=['-O3','-std=c++17'],extra_cuda_cflags=flags,is_python_module=False,verbose=True)
  commands=subprocess.check_output(['ninja','-t','commands'],cwd=builddir,text=True);(run/'t32_reuse-build-commands.txt').write_text(commands)
  actual=[x for x in commands.splitlines() if str(HERE/'native_gqa_t32_reuse.cu') in x]
  require(len(actual)==1 and all(x in actual[0] for x in flags),'B actual compile not t32_reuse/fixed target')
  require('-DCOREX_NATIVE_GQA_V_OVERLAP=' not in actual[0] and not any(x in actual[0] for x in ['-ffast-math','--use_fast_math']),'Unknown B math flags')
  result['compile_proof']=json.loads((HERE/'compile-proof.json').read_text())
  result['t32_reuse']=dict(library=str(private_lib),sha256=sha(private_lib),namespace='corex_native_gqa_t32_reuse_component',
   actual_cuda_command=actual[0],source_sha256=sha(HERE/'native_gqa_t32_reuse.cu'),overlap_v=True,
   frozen_source='7db363d4 unchanged; 121814 reuse compiler proof is separate; old16KiB T32 negative retained')
  op0=torch.ops.corex_native_gqa_s2_probe.produce
  op1=torch.ops.corex_native_gqa_t32_reuse_component.produce
  require(str(op0)!=str(op1),'Torch operator namespaces collided')
  torch.manual_seed(725013)
  B,segments,L=64,2,16384
  common,query,key,value,cache=make_data(torch,[1]*B,L);query[B:]=-17
  table_cpu=torch.zeros((B,8192),dtype=torch.int32_reuse)
  table_cpu[:,:1024]=torch.arange(B*1024,dtype=torch.int32_reuse).reshape(B,-1).reshape(B,-1,4).flip(-1).reshape(B,-1)
  require(int(table_cpu[:,:1024].min())>=0 and int(table_cpu[:,:1024].max())<cache.size(0),'Unsafe physical page IDs')
  common.block_table_tensor=table_cpu.cuda()
  common.seq_lens.copy_(torch.full((B,),4096,dtype=torch.int32_reuse));common.max_seq_len=4096
  common.slot_mapping.copy_(torch.tensor([int(table_cpu[row,255])*16+15 for row in range(B)],dtype=torch.int64))
  spec=FullAttentionSpec(block_size=16,num_kv_heads=2,head_size=128,dtype=torch.bfloat16)
  builder=backend.TritonAttentionMetadataBuilder(spec,['synthetic.attn'],config,torch.device('cuda:0'))
  impl=backend.TritonAttentionImpl(num_heads=16,head_size=128,scale=128**-.5,num_kv_heads=2,alibi_slopes=None,
   sliding_window=None,kv_cache_dtype='auto',attn_type=backend.AttentionType.DECODER)
  layer=NS(_q_scale=torch.ones((),device='cuda'),_k_scale=torch.ones((),device='cuda'),_v_scale=torch.ones((),device='cuda'))
  metadata=builder.build(0,common);impl.do_kv_cache_update(layer,key,value,cache,common.slot_mapping)
  original_try=runtime.try_produce;had_try_attr='try_produce' in runtime.__dict__
  prior_attr=runtime.__dict__.get('try_produce');native_records=[]
  def observe_native(grid,kw):
   selected=original_try(grid,kw);native_records.append((grid,dict(kw),selected));return selected
  original_reducer=gqa._reduce_partials;reduce_capture=Capture(original_reducer)
  runtime.try_produce=observe_native;gqa._reduce_partials=reduce_capture;restore_needed=True
  production_output=torch.full_like(query,-17)
  try:impl.forward(layer,query,key,value,cache,metadata,production_output)
  finally:
   if had_try_attr:runtime.try_produce=prior_attr
   else:del runtime.try_produce
   gqa._reduce_partials=original_reducer;restore_needed=False
  require(('try_produce' in runtime.__dict__)==had_try_attr,'Runtime instance method capture not restored')
  require(runtime.try_produce.__func__ is native._Runtime.try_produce and runtime.try_produce.__self__ is runtime,'Runtime binding changed')
  require(len(native_records)==1 and native_records[0][2] is True and len(reduce_capture.records)==1,'Actual backend did not use one c8a725 producer+reducer')
  grid,kwargs,_=native_records[0];rgrid,rkwargs,reducer_compiled=reduce_capture.records[0]
  require(tuple(grid)==(64,2,2) and tuple(rgrid)==(64,16),'Unexpected actual split/grid')
  require(tuple(kwargs['query_ptr'].stride())==(2048,128,1) and tuple(kwargs['query_ptr'].shape)==(64,16,128),'Expected actual contiguous2048 Q')
  require(kwargs['SEGMENTS']==2 and kwargs['num_warps']==kwargs['num_stages']==1 and kwargs['PAGE_SIZE']==16,'Wrong actual GQA geometry')
  require(all(kwargs[n].stride()==(8192,256,128,1) for n in ['key_cache_ptr','value_cache_ptr']),'Wrong actual NHD strides')
  result['actual_production_binding']=dict(runtime_class=type(runtime).__name__,library_sha256=runtime.library_sha256,
   native_taken=True,grid=list(grid),reducer_grid=list(rgrid),reducer_hash=reducer_compiled.hash,
   Q_stride=list(kwargs['query_ptr'].stride()),lengths=common.seq_lens.cpu().tolist(),
   setup_capture_restored=True,scope='one synthetic backend call, not request coverage ratio')
  tensors=(query,key,value,cache,common.seq_lens,common.block_table_tensor)
  def snapshots():return tuple(x.clone() for x in tensors)
  def same(a,b):
   return torch.equal(a.view(torch.int16 if a.element_size()==2 else torch.int32_reuse),b.view(torch.int16 if b.element_size()==2 else torch.int32_reuse))
  def read_only(before):return all(same(a,b) for a,b in zip(tensors,before))
  initial_inputs=snapshots();rng_cpu=torch.get_rng_state().clone();rng_gpu=torch.cuda.get_rng_state().clone()
  def rng_ok():return torch.equal(rng_cpu,torch.get_rng_state()) and torch.equal(rng_gpu,torch.cuda.get_rng_state())
  arms={}
  for name,operator in [('macro1',op0),('t32_reuse',op1)]:
   out=torch.full_like(query,-17);partial=torch.full_like(metadata.softmax_segm_output,-17)
   maximum=torch.full_like(metadata.softmax_segm_max,-17);summation=torch.full_like(metadata.softmax_segm_expsum,-17)
   pk=dict(kwargs,segm_output_ptr=partial.narrow(2,0,2),segm_max_ptr=maximum.narrow(2,0,2),segm_expsum_ptr=summation.narrow(2,0,2))
   for ptr,dim,keyname in [('segm_output_ptr',0,'segment_stride_token'),('segm_output_ptr',1,'segment_stride_head'),('segm_output_ptr',2,'segment_stride_segment'),
    ('segm_max_ptr',0,'max_stride_token'),('segm_max_ptr',1,'max_stride_head'),('segm_expsum_ptr',0,'max_stride_token'),('segm_expsum_ptr',1,'max_stride_head')]:
    require(pk[ptr].stride(dim)==pk[keyname],'Private scratch ABI changed')
   rk=dict(rkwargs,output_ptr=out[:64],segm_output_ptr=pk['segm_output_ptr'],segm_max_ptr=pk['segm_max_ptr'],segm_expsum_ptr=pk['segm_expsum_ptr'])
   def call(op=operator,pk=pk,rk=rk):
    op(pk['query_ptr'],pk['key_cache_ptr'],pk['value_cache_ptr'],pk['seq_lens_ptr'],pk['block_table_ptr'],
     pk['segm_output_ptr'],pk['segm_max_ptr'],pk['segm_expsum_ptr'],pk['softmax_scale_log2e'])
    return original_reducer[rgrid](**rk)
   arms[name]=NS(call=call,out=out,partial=partial,maximum=maximum,summation=summation,
    all_tensors=(out,partial,maximum,summation),tensors=(out,partial,maximum,summation),maxima=maximum,sums=summation)
  for arm in arms.values():require(arm.call().hash==reducer_compiled.hash,'Wrong common reducer')
  torch.cuda.synchronize()
  require(same(production_output,arms['macro1'].out),'Direct current macro1 A differs from actual backend output')
  require(read_only(initial_inputs) and rng_ok(),'Initial native calls mutated inputs/RNG')
  initial_states={n:tuple(t.clone() for t in a.tensors) for n,a in arms.items()}
  active=B
  same_bits=same
  result["numerical_contract"] = dict(source="scripts/remote/validate_mapped_decode.py:70-92",
      atol=0.03, rtol=0.03, relative_l2_limit=0.01,
      description="新T32数学顺序；沿原独立FP64阈值，cross-arm/partial bitwise仅诊断，同arm Graph/eager与tail poison仍逐位；不是模型准确率")
  stream = torch.cuda.Stream()
  stream.wait_stream(torch.cuda.current_stream())
  with torch.cuda.stream(stream):
      for arm in arms.values():
          arm.call()
  torch.cuda.current_stream().wait_stream(stream)
  torch.cuda.synchronize()
  result['side_stream_bits']=all(same_bits(a,b) for name,arm in arms.items() for a,b in zip(initial_states[name],arm.tensors))
  require(result['side_stream_bits'] and read_only(initial_inputs) and rng_ok(),'Side-stream state/input/RNG changed')
  for arm in arms.values():
      arm.graph = torch.cuda.CUDAGraph()
      with torch.cuda.graph(arm.graph, stream=stream):
          arm.call()
  torch.cuda.synchronize()

  def check(label, finite=True, changed=False):
      # 整份 KV/输入逐位和 RNG 门在计时外；失败也先保存响应与 partial。
      before = snapshots()
      rng_cpu, rng_gpu = torch.get_rng_state().clone(), torch.cuda.get_rng_state().clone()
      for arm in arms.values():
          for tensor in arm.tensors:
              tensor.fill_(-17)
          arm.call()
      torch.cuda.synchronize()
      a, b = arms["macro1"], arms["t32_reuse"]
      expected = {name: tuple(t.clone() for t in arm.tensors) for name, arm in arms.items()}
      oracle = sampled_reference(torch, run, label, query, cache, common.seq_lens,
          common.block_table_tensor, {name: arm.out for name, arm in arms.items()}, active) if finite else None
      checks = dict(eager_numerics=(all(row["passed"] for row in oracle["arms"].values()) if finite else
          bool(torch.equal(torch.isnan(a.out[:B]), torch.isnan(b.out[:B])) and
               torch.equal(torch.isposinf(a.out[:B]), torch.isposinf(b.out[:B])) and
               torch.equal(torch.isneginf(a.out[:B]), torch.isneginf(b.out[:B])))),
          finite=(all(bool(torch.isfinite(arm.out[:B]).all()) for arm in arms.values()) if finite else True),
          guard=bool((a.out[B:] == -17).all() and (b.out[B:] == -17).all()))
      cross_arm_bitwise_diagnostic = same_bits(a.out[:B], b.out[:B])
      partial_bitwise_diagnostic=all(same_bits(x,y) for x,y in zip((a.partial,a.maxima,a.sums),(b.partial,b.maxima,b.sums)))
      if active < B:
          checks["padded_output_zero"] = all(bool((arm.out[active:B] == 0).all()) for arm in arms.values())
          checks["padded_partials_untouched"] = all(bool((t[active:B] == -17).all())
              for arm in arms.values() for t in (arm.partial, arm.maxima, arm.sums))
      else:
          checks["padded_output_zero"] = True
          checks["padded_partials_untouched"] = True
      # Cross-arm partial values legitimately differ. Preserve the original
      # no-write contract explicitly for holes, empty segments and storage tail.
      lengths=common.seq_lens[:B]
      steps=(lengths+segments*16-1)//(segments*16)
      writable=(torch.arange(segments,device=lengths.device)[None,:]*steps[:,None]*16)<lengths[:,None]
      storage_ok=True
      for arm in arms.values():
          for tensor in (arm.partial,arm.maxima,arm.sums):
              guard_mask=torch.ones_like(tensor,dtype=torch.bool)
              live=writable[:,None,:]
              if tensor.dim()==4:live=live[:,:,:,None]
              guard_mask[:B,:,:segments]=~live
              storage_ok=storage_ok and bool((tensor[guard_mask]==-17).all())
      checks['scratch_unwritten_storage']=storage_ok
      failed_eager = [t.cpu() for t in b.tensors] if not checks["eager_numerics"] else None
      for arm in arms.values():
          for tensor in arm.tensors:
              tensor.fill_(-17)
          arm.graph.replay()
      torch.cuda.synchronize()
      checks["graph_fresh_bits"] = all(same_bits(x, y) for name, arm in arms.items()
          for x, y in zip(expected[name], arm.tensors))
      checks["inputs_unchanged"] = read_only(before)
      checks["rng_unchanged"] = torch.equal(rng_cpu, torch.get_rng_state()) and torch.equal(rng_gpu, torch.cuda.get_rng_state())
      if changed:
          checks["output_changed"] = all(not same_bits(initial_output[name][:B], expected[name][0][:B]) for name in arms)
      record = dict(case=label, checks=checks, independent_reference=oracle, nonfinite_diagnostic=not finite,
                    baseline_nan=int(torch.isnan(a.out[:B]).sum().item()),
                    candidate_nan=int(torch.isnan(b.out[:B]).sum().item()))
      record["cross_arm_bitwise_diagnostic"] = cross_arm_bitwise_diagnostic
      record["all_partial_state_cross_arm_bitwise_diagnostic"] = partial_bitwise_diagnostic
      result["checks"].append(record)
      torch.save({"macro1": [x.cpu() for x in expected["macro1"]], "t32_reuse": [x.cpu() for x in b.tensors],
                  "failed_eager_candidate": failed_eager,
                  "seq_lens": common.seq_lens.cpu(), "query": query.cpu(),
                  "block_table": common.block_table_tensor.cpu()}, run / (label + ".pt"))
      write(run / "results.json", result)
      if not all(checks.values()):
          torch.save(cache.cpu(), run / (label + "-failed-kv.pt"))
          raise RuntimeError("新增数值/Graph 边界失败：" + label + repr(checks))
      return {name:values[0] for name,values in expected.items()}

  initial_output = check("dense-random")
  query[:B].neg_()
  # row15 remains long in the ragged pattern; mutate pages it actually reads.
  changed_row = 15
  changed_page = changed_row * (L // 16) + (1 if active < B else 0)
  cache[changed_page, 1].add_(0.5)
  common.block_table_tensor[changed_row, :2].copy_(common.block_table_tensor[changed_row, :2].flip(0))
  ragged_pattern = [0, 1, 15, 16, 17, 31, 32, 33, 63, 64, 65, 4095, 4096, 4097, 16383, 16384]
  ragged = [ragged_pattern[i % len(ragged_pattern)] for i in range(active)] + [0] * (B - active)
  common.seq_lens.copy_(torch.tensor(ragged, dtype=torch.int32_reuse, device="cuda"))
  ragged_output=check("graph-changed-q-kv-pages-ragged-zero-tail", changed=True)
  # New native-specific boundary: legal tail page may contain NaN in unused
  # K and V slots. Original masked-load semantics must survive the SME read.
  for row,length in enumerate(ragged):
      if length>0 and length%16:
          page=int(common.block_table_tensor[row,(length-1)//16].cpu())
          cache[page,:,length%16:].fill_(float('nan'))
  tail_output=check('tail-unused-KV-NaN-masked')
  if not all(same_bits(ragged_output[name],tail_output[name]) for name in arms):raise RuntimeError('尾槽poison改变了本arm有效输出')
  result["tail_poison_output_unchanged"]=True
  # 保原page16分段，覆盖整页、尾页、空段及零长Graph行。
  boundary = [0, 1, 15, 16, 17, segments * 16, segments * 80 - 32, segments * 80 - 29]
  common.seq_lens.copy_(torch.tensor([boundary[i % 8] for i in range(active)] + [0] * (B - active),
                                     dtype=torch.int32_reuse, device="cuda"))
  query[:B].zero_()
  cache.zero_()
  cache[:, 1].fill_(-0.0)
  check("finite-equal-max-negative-zero-v")
  tiny = torch.tensor([2.0 ** -133, -(2.0 ** -133), 2.0 ** -126, -(2.0 ** -126)],
                      dtype=torch.bfloat16, device="cuda")
  cache[:, 1].copy_(tiny.repeat(32).reshape(1, 1, 1, 128).expand_as(cache[:, 1]))
  check("finite-equal-max-subnormal-cancellation-v")
  cache[:, 1].fill_(float("nan"))
  cache[:, 1, :, :, 0].fill_(float("inf"))
  cache[:, 1, :, :, 1].fill_(float("-inf"))
  check("finite-max-nonfinite-accumulator", finite=False)
  cache[:, 1].fill_(1.0)
  query[:B].fill_(1.0)
  cache[:, 0].fill_(float("-inf"))
  check("negative-infinity-max-original-path", finite=False)
  cache[:, 0].fill_(float("inf"))
  check("positive-infinity-max-original-path", finite=False)

  for target, saved in zip(tensors, initial_inputs):
      target.copy_(saved)
  restored_output=check("restored-dense-before-ABBA")
  require(all(same_bits(initial_output[name],restored_output[name]) for name in arms),"Restored fixture output differs")
  require(read_only(initial_inputs) and rng_ok(),"Restored inputs/RNG changed")
  for arm in arms.values():
      arm.graph.replay()
  result['timing_contract']=dict(order=['macro1','t32_reuse','t32_reuse','macro1'],loops_per_window=32,
   per_replay=['one native producer','one unchanged original reducer'],writer_in_timing=False,
   input='restored exact initial seed725013; N64/S2/KV4096/Qstride2048',SO0=GQA_SHA,SO1=sha(private_lib))
  events=[(torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)) for _ in range(4)]
  for start,end in events:start.record();end.record()
  torch.cuda.synchronize();db=Path('/root/.flaggems/config_cache/TunedConfig_iluvatar_triton_3_6.db');db_before=digest(db)
  for name,pair in zip(('macro1','t32_reuse','t32_reuse','macro1'),events):
   rec=timed_batch(torch,arms[name].graph.replay,pair,32);rec['arm']=name;result['timings'].append(rec);write(run/'results.json',result)
  require(digest(db)==db_before,'Common DB changed during ABBA')
  result['summary']={}
  for metric in ('event','wall'):
   a=statistics.median(x[metric+'_per_call_ms'] for x in result['timings'] if x['arm']=='macro1')
   b=statistics.median(x[metric+'_per_call_ms'] for x in result['timings'] if x['arm']=='t32_reuse')
   result['summary'][metric]=dict(macro1_ms=a,t32_reuse_ms=b,fraction_saved=1-b/a)
  result.update(status='component_only_passed' if result['summary']['event']['fraction_saved']>0 else 'stopped_negative',
   decision='Strict same-run macro1/t32_reuse component only; no automatic shape or official chain')
 except BaseException:
  result.update(status='failed_stop',error=traceback.format_exc());traceback.print_exc()
 finally:
  if restore_needed:
   if had_try_attr:runtime.try_produce=prior_attr
   else:del runtime.try_produce
   gqa._reduce_partials=original_reducer
  write(run/'results.json',result)
 return 0 if result['status'] in ('component_only_passed','stopped_negative') else 1
