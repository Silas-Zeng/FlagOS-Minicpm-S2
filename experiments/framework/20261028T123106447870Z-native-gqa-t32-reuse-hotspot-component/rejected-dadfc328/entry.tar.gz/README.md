# T32 8 KiB原位复用：固定S2完整组件

A仍为当前PR105 macro1成品 `c8a725da`；B为 `7db363d4`，仅把已验证T32的K存储在QK完成屏障后复用于V。121814实际编译8 KiB、64 SGPR/80 VGPR、零spill；V重叠窗口缩短、增加一道安全barrier，不能从shared减半推断实际occupancy或收益。

继承120451 T32的固定九门及数值合同，因新的共享生命周期全部重走。FP64 helper、`.03/.03/relative L2≤.01`、finite/NaN/Inf、tail poison、逐臂Graph/eager和side、未写storage、输入/RNG全部保持；跨臂output/partial bitwise仍只是诊断。没有新shape、三臂或旧T32性能重测。

恢复原N64/S2/KV4096输入后，仅同producer＋同reducer的Graph ABBA32。负则停止；正也只是组件信号，不是官方吞吐/模型资格。旧16 KiB T32慢3.7522%的结果保留。`worker.py.diff` 显示仅身份更新；owner、原A源码/SO、九门及清理复用。只有主智能体运行启动脚本。
