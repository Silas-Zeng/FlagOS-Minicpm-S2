"""最薄接线检查：121814原件身份、核/桥符号与完整旧门不变。"""
from pathlib import Path
import ast,hashlib,json
H=Path(__file__).resolve().parent;R=H.parent.parent
BASE=H.parent/'native-gqa-t32-component-20261028'
SRC=H.parent/'native-gqa-t32-reuse-compile-20261028'
A=R/'archive/hotspot-layout-20261026/batch-121814-native-gqa-t32-reuse-compile/cpu-probes/20261028T121814Z-native-gqa-t32-reuse-compile'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks={}
checks['source7db_frozen']=sha(H/'native_gqa_t32_reuse.cu')=='7db363d4b9d4d5c16fdc99bb710ccd0023a65752324a2d340d31d7e71ac57ed8' and (H/'native_gqa_t32_reuse.cu').read_bytes()==(SRC/'native_gqa_t32_reuse.cu').read_bytes()
checks['actual121814_bound']=sha(A/'gqa.ll')=='8d0308c049b30d0ef3bdd37889eff23dbb39acab266fd6405539a035f8924078' and sha(A/'gqa.s')=='67549bfb22a34514cf265e9c1e7b0d0a63986b13c4f9df93f07caa472573a154'
resources=json.loads((A/'compile-check.json').read_text(encoding='utf-8'))['resources']
checks['actual8KiB_zero_spill']=len(resources)==1 and resources[0]['group_segment_fixed_size']==8192 and resources[0]['private_segment_fixed_size']==resources[0]['sgpr_spill_count']==resources[0]['vgpr_spill_count']==0
checks['bridge_symbols_only']=(H/'bridge.cpp').read_text(encoding='utf-8').replace('t32_reuse','t32')==(BASE/'bridge.cpp').read_text(encoding='utf-8')
checks['owner_run_label_only']=(H/'entry.py').read_text(encoding='utf-8').replace('-native-gqa-t32-reuse-','-native-gqa-t32-')==(BASE/'entry.py').read_text(encoding='utf-8')
old=(BASE/'worker.py').read_text(encoding='utf-8');w=(H/'worker.py').read_text(encoding='utf-8')
inverse=w.replace('t32_reuse','t32').replace('7db363d4','f2975861').replace('8KiB T32原位复用','逻辑T32')
inverse=inverse.replace('T32 reuse8KiB keeps parent math and changes shared lifetime; all nine GPU gates rerun, no new performance qualification.','T32 saves normalization/rescale groups, has no numerical/performance qualification.')
inverse=inverse.replace('121814 reuse compiler proof is separate; old16KiB T32 negative retained','T32 compiler proof is separate; old double-slot negative retained')
checks['worker_identity_only_full_inverse']=inverse==old
names=['base-source-manifest.json','dispatch_bootstrap.py','distributed_bootstrap.py','legacy_gate.py','monitor_gpu.sh','validate_block_table_candidate.py','validate_hidden_row_gather.py','validate_mixed_decode.py','fp_reference.py','macro1-build-receipt.json','source_identity.py']
checks['11_prior_assets_unchanged']=all((H/n).read_bytes()==(BASE/n).read_bytes() for n in names)
for p in H.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'))
checks['Python_syntax_no_device_import']=True
proof=dict(CPU_only=True,source_sha256=sha(H/'native_gqa_t32_reuse.cu'),LLVM_sha256=sha(A/'gqa.ll'),ASM_sha256=sha(A/'gqa.s'),
 artifact=A.relative_to(R).as_posix(),resources=resources,independent_review='root核实际K读完成→barrier→原位V写及Vwait/tail→PV，不重复完整旧数学证明。',
 resource_scope='独立CPU编译身份；实际extension命令/SO由worker另存，不冒充精确资源。',
 numerical_contract='全部继承已过120451九门T32；因新共享地址/生命周期，九门实际再跑，不改门/shape。')
(H/'compile-proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
report=dict(CPU_only=True,checks=checks,passed=all(checks.values()),reused='完整worker除B身份/标签外逐字逆回baa8；所有硬门和ABBA32原样，无三臂。',
 pending='root实际CFG独审与唯一S2 GPU；当前未授数值或性能资格。')
(H/'cpu-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert all(checks.values()),checks
print(json.dumps(report,ensure_ascii=False))
