"""Validate ordinary and editable installs of the two release ZIPs on BI-V150."""
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import urllib.request
import zipfile

root = Path("/workspace/experiments/minicpm-s2")
run = Path(__file__).resolve().parent
packages = {"FlagGems": ("src/flag_gems/", "flag_gems"), "vllm-plugin-FL": ("vllm_fl/", "vllm_fl")}
baseline = root / "code/20261120T082740Z-final-main-accuracy/installed"
env = {k: v for k, v in os.environ.items() if not k.startswith(("SETUPTOOLS_SCM_", "VLLM_FL_", "BIV150_"))}
for name in ("VLLM_VENDOR", "PYTHONPATH", "VLLM_PLUGINS"):
    env.pop(name, None)
env.update(PIP_DISABLE_PIP_VERSION_CHECK="1", PYTHONUNBUFFERED="1")
target = run / "installed"
state = {"run": run.name, "source": json.loads((run / "identity.json").read_bytes()), "owner_pid": os.getpid()}


def status(phase):
    state["phase"] = phase
    temp = run / "status.tmp"
    temp.write_text(json.dumps(state, ensure_ascii=False, indent=2))
    temp.replace(run / "status.json")


def log_command(name, cmd, child_env=None):
    with (run / (name + ".log")).open("w") as f:
        subprocess.run(cmd, cwd=run, env=child_env or env, stdout=f, stderr=subprocess.STDOUT, check=True)


def test():
    gate_spec = importlib.util.spec_from_file_location("gate", root / "scripts/run_accuracy_gate.py")
    gate = importlib.util.module_from_spec(gate_spec)
    gate_spec.loader.exec_module(gate)
    with (root / "framework-device.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        state["preflight"] = gate.preflight()
        status("源码包安装")
        for package in packages:
            archive = run / (package + ".zip")
            assert hashlib.sha256(archive.read_bytes()).hexdigest() == state["source"][package]["sha256"]
            log_command("extract-" + package, ["unzip", "-q", str(archive), "-d", str(run)])
            assert not (run / package / ".git").exists()
        pip = [sys.executable, "-m", "pip", "install", "--no-build-isolation", "--no-deps", "--no-index", "--no-cache-dir"]
        paths = [str(run / name) for name in packages]
        log_command("install", [*pip, "--target", str(target), *paths])
        state["runtime_files"] = {}
        for name, (prefix, module) in packages.items():
            with zipfile.ZipFile(run / (name + ".zip")) as z:
                start = name + "/" + prefix
                counts = {"py": 0, "yaml": 0}
                for key in z.namelist():
                    if not key.startswith(start) or not key.endswith((".py", ".yaml")):
                        continue
                    relative = Path(module) / key.removeprefix(start)
                    original = z.read(key)
                    assert (target / relative).read_bytes() == original, str(relative)
                    assert (baseline / relative).read_bytes() == original, "105题受测文件不同: " + str(relative)
                    counts[relative.suffix[1:]] += 1
                state["runtime_files"][name] = counts
        with zipfile.ZipFile(run / "FlagGems.zip") as z:
            suite_counts = {}
            for src, installed in [("tests", "flaggems_tests"), ("benchmark", "flaggems_benchmark")]:
                start = "FlagGems/" + src + "/"
                members = [k for k in z.namelist() if k.startswith(start) and not k.endswith("/")]
                for key in members:
                    relative = Path(installed) / key.removeprefix(start)
                    assert (target / relative).read_bytes() == z.read(key), str(relative)
                suite_counts[installed] = len(members)
            state["bundled_suite_files"] = suite_counts
        child_env = dict(env, PYTHONPATH=str(target), VLLM_PLUGINS="fl")
        versions = subprocess.check_output([sys.executable, "-c", "import json,importlib.metadata as m;print(json.dumps({n:m.version(n) for n in ['flag-gems','vllm-plugin-fl']}))"],
                                           cwd=run, env=child_env, text=True)
        state["zip_distribution_versions"] = json.loads(versions)
        status("可编辑安装")
        edit = run / "editable"
        log_command("editable", [*pip, "--target", str(edit), "-e", paths[0], "-e", paths[1]])
        probe = """
import importlib.util, json, site, sys
from pathlib import Path
site.addsitedir(sys.argv[1])
expected = {"flag_gems": Path(sys.argv[2])/"src/flag_gems/__init__.py", "vllm_fl": Path(sys.argv[3])/"vllm_fl/__init__.py"}
loaded = {key: Path(importlib.util.find_spec(key).origin).resolve() for key in expected}
assert loaded == expected, loaded
print(json.dumps({k: str(v) for k,v in loaded.items()}))
"""
        state["editable_origins"] = json.loads(subprocess.check_output([sys.executable, "-S", "-c", probe, str(edit), *paths], env=env, cwd=run, text=True))
        origin_probe = """
from pathlib import Path
import sys, flag_gems, vllm_fl
from flag_gems.fused.DSA import bin_topk, sparse_mla
for module in (flag_gems, vllm_fl, bin_topk, sparse_mla):
    assert Path(module.__file__).is_relative_to(sys.argv[1]), module.__file__
    print(module.__name__, module.__file__)
"""
        log_command("imports", [sys.executable, "-c", origin_probe, str(target)], child_env)
        gate.preflight()
        state["server_command"] = gate.SERVER
        with (run / "server.log").open("w") as log:
            server = subprocess.Popen(gate.SERVER, cwd=run, env=child_env, stdout=log, stderr=subprocess.STDOUT,
                                      start_new_session=True, stdin=subprocess.DEVNULL)
        try:
            state["server_pid"] = server.pid
            status("服务启动")
            gate.wait_ready(server, None, run)
            status("生成验证")
            req = {"model": "minicpm", "prompt": ["The capital of France is", "One plus one equals"], "temperature": 0, "max_tokens": 12}
            def post(endpoint, body):
                call = urllib.request.Request("http://127.0.0.1:9031/v1/" + endpoint,
                    data=json.dumps(body).encode(), headers={"Content-Type": "application/json"})
                with urllib.request.urlopen(call, timeout=180) as response:
                    return json.load(response)
            done = post("completions", req)
            (run / "responses.json").write_text(json.dumps(done, ensure_ascii=False, indent=2))
            old = json.loads((root / "20261120T071826Z-team-triton-clean-smoke/response.json").read_bytes())
            texts = [v["text"] for v in done["choices"]]
            assert len(texts) == 2 and all(t.strip() for t in texts)
            state.update(batch_generated=len(texts), completion_tokens=done["usage"]["completion_tokens"],
                         same_greedy_outputs=texts == [v["text"] for v in old["choices"]])
            math = post("chat/completions", {"model": "minicpm", "messages": [{"role":"user","content":"What is 2 + 3? Give the final answer as a single number."}],
                "temperature": 0, "max_tokens": 512})
            (run / "math-response.json").write_text(json.dumps(math, ensure_ascii=False, indent=2))
            choice = math["choices"][0]
            answer = choice["message"]["content"].strip()
            assert "5" in answer and choice["finish_reason"] == "stop", (answer, choice["finish_reason"])
            state["math_answer"] = answer
        finally:
            gate.stop_owned_group(server)
            state["postflight"] = gate.preflight()
        status("通过")


if __name__ == "__main__":
    try:
        test()
    except BaseException as error:
        state["error"] = repr(error)
        status("失败")
        raise
